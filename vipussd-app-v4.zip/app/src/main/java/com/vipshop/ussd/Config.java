package com.vipshop.ussd;

import android.content.Context;
import android.content.SharedPreferences;

/* O endereço do servidor fica fixo no código (não é mostrado a quem usa a app). */
public class Config {
    static final String SERVIDOR = "http://78.154.103.14:16701";

    static SharedPreferences p(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }
    static String servidor(Context c) { return SERVIDOR; }
    static String token(Context c) { return p(c).getString("token", ""); }
    static void guardarToken(Context c, String t) { p(c).edit().putString("token", t).apply(); }
    static boolean pronto(Context c) { return !token(c).isEmpty(); }
}
