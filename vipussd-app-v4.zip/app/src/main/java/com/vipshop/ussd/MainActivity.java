package com.vipshop.ussd;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

/* Um só ecrã: escreve o código de acesso ou um pedido e toca em PEDIR ACESSO. */
public class MainActivity extends Activity {
    private EditText campo;
    private TextView estado;

    @Override
    protected void onCreate(Bundle guardado) {
        super.onCreate(guardado);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(48, 48, 48, 48);
        sv.addView(r);

        ImageView capa = new ImageView(this);
        capa.setImageResource(R.drawable.capa_vip);
        capa.setAdjustViewBounds(true);
        r.addView(capa);

        TextView titulo = new TextView(this);
        titulo.setText("VIP BOT AUTO");
        titulo.setTextSize(22);
        titulo.setTextColor(Color.parseColor("#FFD700"));
        titulo.setPadding(0, 24, 0, 8);
        r.addView(titulo);

        TextView sub = new TextView(this);
        sub.setText("Escreve o código de acesso ou um pedido (ex: VIP) e toca em PEDIR ACESSO.");
        sub.setTextSize(14);
        sub.setTextColor(Color.parseColor("#BBBBBB"));
        r.addView(sub);

        campo = new EditText(this);
        campo.setHint("Código ou pedido");
        campo.setTextColor(Color.WHITE);
        campo.setHintTextColor(Color.parseColor("#777777"));
        r.addView(campo);

        Button b = new Button(this);
        b.setText("PEDIR ACESSO");
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#E0344B"));
        b.setOnClickListener(v -> enviar());
        r.addView(b);

        estado = new TextView(this);
        estado.setTextColor(Color.parseColor("#BBBBBB"));
        estado.setPadding(0, 16, 0, 0);
        r.addView(estado);

        setContentView(sv);

        if (Config.pronto(this)) {
            Intent i = new Intent(this, BridgeService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }
    }

    private void enviar() {
        final String t = campo.getText().toString().trim();
        if (t.isEmpty()) {
            estado.setText("Escreve primeiro o código ou o pedido.");
            return;
        }
        estado.setText("A enviar...");
        new Thread(() -> {
            try {
                String msg;
                if (t.toUpperCase().startsWith("VIP-")) {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/ativar", t));
                    msg = o.optBoolean("ok") ? "Acesso ativo até: " + o.optString("validade")
                            : "Não foi possível: " + o.optString("erro");
                } else {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/pedir", t));
                    msg = o.optBoolean("ok") ? "Pedido enviado. Aguarde a aprovação. ID: " + o.optString("id")
                            : "Não foi possível enviar o pedido.";
                }
                mostrar(msg);
            } catch (Exception e) {
                mostrar("Sem ligação ao servidor. Tenta de novo.");
            }
        }).start();
    }

    private void mostrar(String t) {
        runOnUiThread(() -> estado.setText(t));
    }
}
